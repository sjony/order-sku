package com.sjony.study.dy.Taxi;

import java.math.BigDecimal;
import java.util.Date;

/**
 * Created by sjony on 2018/3/26.
 */
public interface TaxiRun {

    Double getRunTotal(Double startTime, Double distance);

}
